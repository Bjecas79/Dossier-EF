// sw.js — Service Worker para Dossier EF PWA
const CACHE_NAME = 'dossier-ef-v1';

// Ficheiros a guardar em cache para uso offline
const ASSETS_TO_CACHE = [
  './Dossier__Prof_EF_Hugo_PWA.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  'https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap'
];

// Instalação: guarda assets em cache
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] A guardar ficheiros em cache...');
      // Cache dos assets locais (não falha se algum externo falhar)
      return cache.addAll(ASSETS_TO_CACHE.filter(url => !url.startsWith('http')))
        .then(() => {
          // Tenta cache de recursos externos separadamente
          return Promise.allSettled(
            ASSETS_TO_CACHE.filter(url => url.startsWith('http'))
              .map(url => cache.add(url).catch(() => {}))
          );
        });
    }).then(() => self.skipWaiting())
  );
});

// Activação: limpa caches antigas
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

// Intercepção de pedidos: Cache First para assets locais, Network First para API
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API do Open-Meteo (meteorologia) — sempre tenta rede primeiro
  if (url.hostname === 'api.open-meteo.com') {
    event.respondWith(
      fetch(event.request)
        .catch(() => new Response(JSON.stringify({error: 'offline'}), {
          headers: {'Content-Type': 'application/json'}
        }))
    );
    return;
  }

  // Google Fonts — Cache First
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          return response;
        }).catch(() => new Response('', {status: 503}));
      })
    );
    return;
  }

  // Assets locais — Cache First, fallback rede
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        // Guarda em cache se for um pedido GET bem-sucedido
        if (event.request.method === 'GET' && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});
